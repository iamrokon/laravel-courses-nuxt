<template lang="">
    <div>
        <h2>Header</h2>
        <slot/>
        <h2>Footer</h2>
    </div>
</template>