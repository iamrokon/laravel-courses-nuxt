<template lang="">
    <h2>Style 2</h2>
    <slot/>
    <h2>Test</h2>
</template>