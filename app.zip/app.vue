<template lang="">
    <div>
        <NuxtPage/>
    </div>
</template>