<template lang="">
    <h2>Home</h2>
    <NuxtLink to="/about">About</NuxtLink>
    <ul>
        <li v-for="user in users" :key="user.id">{{user.name}}</li>
    </ul>
    <p></p>
    <ul>
        <li v-for="user in users2" :key="user.id">{{user.name}}</li>
    </ul>
    <div v-if="loading">
        Loading...
    </div>
    <div v-else>
        <ul>
            <li v-for="user in users3" :key="user.id">{{user.name}}</li>
        </ul>
    </div>
    <p><Button /></p>
</template>

<script setup>
const users = await $fetch('https://jsonplaceholder.typicode.com/users');
const {data:users2} = await useFetch('https://jsonplaceholder.typicode.com/users');
const {loading, data:users3} = await useLazyFetch('https://jsonplaceholder.typicode.com/users');
</script>